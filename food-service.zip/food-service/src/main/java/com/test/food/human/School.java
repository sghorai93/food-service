package com.test.food.human;

public interface School {
	public String typeOfSchool();
}
