package com.test.food.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Food {
	
	private String foodName;
	private String cuisine;
	private Double price;
	
}
